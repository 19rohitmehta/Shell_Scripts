#!/bin/bash
echo
echo -e "\e[1;31mWARNING : This script is strictly meant for first time racadm installation for iDRAC9 remote administration of Dell servers.If mistakenly executed than please terminate the process immediately or contact Mavenir C0D team..\e[0m"
while true; do
    read -p 'Please make sure above all details are correctly filled. Do you want to Continue? yes/no: ' input
    case $input in
        [yY]*)
            echo 'Continuing'
            break
            ;;
        [nN]*)
            echo 'Ok, exiting'
            exit 1
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
tar -xzvf OM-MgmtStat-Dell-Web-LX-9.2.0-3142_A00.tar.gz
sh linux/rac/install_racadm.sh
echo -e "\e[1;31mracadm installation has been completed. Kindly relogin to terminal to enable access to racadm utility\e[0m"

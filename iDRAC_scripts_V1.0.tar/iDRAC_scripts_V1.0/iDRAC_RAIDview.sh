#!/bin/bash
echo
echo -e "\e[1;31mWARNING : This script is strictly meant for RAID layout View for iDRAC9 on Dell servers. If mistakenly executed than please terminate the process immediately or contact Mavenir C0D team. Please make sure below all details are filled correctly.\e[0m"
echo
echo "Dell Server iDRAC IPs :-"
cat iDRAC_Plan
echo
echo "Enter iDRAC User Name (must be same for all iDRACs) :-"
read iDRAC_USER
echo "Enter $iDRAC_USER Password (must be same for all iDRACs) :-"
read iDRAC_PW
echo
while true; do
    read -p 'Please make sure above all details are correctly filled. Do you want to Continue? yes/no: ' input
    case $input in
        [yY]*)
            echo 'Continuing'
            break
            ;;
        [nN]*)
            echo 'Ok, exiting'
            exit 1
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
touch raid.output
cat /dev/null >  raid.output
for iDRAC_IP in $(cat iDRAC_Plan); do
  cat /dev/null >  raidcont
  echo ""  >> raid.output
  echo "Current RAID Layout of Sever $iDRAC_IP" >> raid.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW storage get vdisks -o -p layout,size,StripeSize,status >> raid.output
  echo "________________________________________________________________"  >> raid.output
done
echo -e "\e[1;31mAll configurations have been collected sucessfully. Request you to verify current raid layout in raid.output file in script root directory $(pwd)\e[0m." 

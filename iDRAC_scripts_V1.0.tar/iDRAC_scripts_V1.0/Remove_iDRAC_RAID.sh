#!/bin/bash
echo
echo -e "\e[1;31mWARNING : This script is strictly meant for first time RAID deletion for iDRAC9 on Dell servers and delete existing RAID configuration. if mistakenly executed than please terminate the process immediately or contact Mavenir C0D team. Please make sure below all details are filled correctly.\e[0m"
echo
echo "Dell Server iDRAC IPs :-"
cat iDRAC_Plan
echo
echo "Enter iDRAC User Name (must be same for all iDRACs) :-"
read iDRAC_USER
echo "Enter $iDRAC_USER Password (must be same for all iDRACs) :-"
read iDRAC_PW
echo
while true; do
    read -p 'Please make sure above all details are correctly filled. Do you want to Continue? yes/no: ' input
    case $input in
        [yY]*)
            echo 'Continuing'
            break
            ;;
        [nN]*)
            echo 'Ok, exiting'
            exit 1
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
touch vdisks
touch raidcont
for iDRAC_IP in $(cat iDRAC_Plan); do
  cat /dev/null >  vdisks
  cat /dev/null >  raidcont
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid get vdisks | grep Disk > vdisks 
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW storage get controllers | grep RAID > raidcont
  sed -i 's/[][*]\|[[:space:]]//g' vdisks
  sed -i 's/[][*]\|[[:space:]]//g' raidcont
  CONT=$(cat raidcont)
while true; do
    echo -e "\e[1;31mAvailable Virtual Disks & RAID Controller of $iDRAC_IP\e[0m"
    cat vdisks
    cat raidcont
    echo 
   read -p "Do you want to Delete All Virtual disks of Server $iDRAC_IP? yes/no: " input  
  case $input in
        [yY]*)
      while  read -r line; do
      echo "deleting $line"
      racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid deletevd:$line
      done < "vdisks"
      racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create $CONT --realtime
      break
            ;;
        [nN]*)
      echo 'Ok, Delete Selective or Manually'
         for VDISK in $(cat vdisks); do
         while true; do
    read -p "Do you want to Delete $VDISK of $iDRAC_IP? Enter yes/no (Press E for exiting $iDRAC_IP ): " input
    case $input in
        [yY]*)
            echo "Deleting $VDISK"
         racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid deletevd:$VDISK
            break
            ;;
        [nN]*)
            echo "Ok, Leaving $VDISK"
            break
            ;;
         [Ee]*)
            echo "Ok, Exiting $iDRAC_IP"
            break 2
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
done   
        racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create $CONT --realtime
         break
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
done
echo
echo -e "\e[1;31mAll configurations have been completed. Request you to verify current raid layout by executing iDRAC_RAIDview.sh script (After delay of 180 Seconds of current execution) before you proceed further\e[0m."

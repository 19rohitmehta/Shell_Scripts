#!/bin/bash
echo
echo -e "\e[1;31mWARNING : This script is strictly meant for first time RAID creation for iDRAC9 on Dell servers and override existing RAID configuration. if mistakenly executed than please terminate the process immediately or contact Mavenir C0D team. Please make sure below all details are filled correctly.\e[0m"
echo
echo "Dell Server iDRAC IPs :-"
cat iDRAC_Plan
echo
echo "Enter iDRAC User Name (must be same for all iDRACs) :-"
read iDRAC_USER
echo "Enter $iDRAC_USER Password (must be same for all iDRACs) :-"
read iDRAC_PW
echo
while true; do
    read -p 'Please make sure above all details are correctly filled. Do you want to Continue? yes/no: ' input
    case $input in
        [yY]*)
            echo 'Continuing'
            break
            ;;
        [nN]*)
            echo 'Ok, exiting'
            exit 1
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
touch pdisks
touch raidcont
for iDRAC_IP in $(cat iDRAC_Plan); do
  cat /dev/null >  pdisks
  cat /dev/null >  raidcont
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid get pdisks  > pdisks 
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW storage get controllers | grep RAID > raidcont
  sed -i 's/[][*]\|[[:space:]]//g' pdisks
  sed -i 's/[][*]\|[[:space:]]//g' raidcont
  echo
  echo "Physical Disk layout for server $iDRAC_IP"
  cat pdisks
  echo
  CONT=$(cat raidcont)
  echo -e "\e[1;31mEnter total number of Virtual Disks or RAID Partitions required on server $iDRAC_IP (Integer Value Only) :-\e[0m"
  read VD_NUM
N=1
for ((N=1;N<=VD_NUM;N++))
do
 echo
 echo -e "\e[1;31mEnter Virtual Disk-$N RAID INDEX (Integer Value Only) :-\e[0m"
 read RAID_INDEX 
 if [ $RAID_INDEX == 0 ]
then
   echo
   echo -e "\e[1;31mEnter Disk to be used for Virtual Disk-$N RAID-0 :-\e[0m"
   read DISK1
    racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid createvd:$CONT -rl r0 -wp wb -rp ra -ss 64K -pdkey:$DISK1
elif [ $RAID_INDEX == 1 ]
then
 echo
 echo -e "\e[1;31mEnter First Disk to be used for Virtual Disk-$N RAID-1 :-\e[0m"
   read DISK1
 echo -e "\e[1;31mEnter Second Disk to be used for Virtual Disk-$N RAID-1 :-\e[0m"
   read DISK2
    racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid createvd:$CONT -rl r1 -wp wb -rp ra -ss 64K -pdkey:$DISK1,$DISK2
elif [ $RAID_INDEX == 10 ]
then
 echo
 echo -e "\e[1;31mEnter First Disk to be used for Virtual Disk-$N RAID-10 :-\e[0m"
   read DISK1
 echo -e "\e[1;31mEnter Second Disk to be used for Virtual Disk-$N RAID-10 :-\e[0m"
   read DISK2
 echo -e "\e[1;31mEnter Third Disk to be used for Virtual Disk-$N RAID-10 :-\e[0m"
   read DISK3
 echo -e "\e[1;31mEnter Fourth Disk to be used for Virtual Disk-$N RAID-10 :-\e[0m"
   read DISK4
    racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW raid createvd:$CONT -rl r10 -wp wb -rp ra -ss 64K -pdkey:$DISK1,$DISK2,$DISK3,$DISK4
else
break
fi
done
racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create $CONT --realtime 
done   

echo -e "\e[1;31mAll configurations have been completed. Request you to verify current raid layout by executing iDRAC_RAIDview.sh script (After delay of 180 Seconds of current execution) before you proceed further\e[0m."

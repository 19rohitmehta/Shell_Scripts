#!/bin/bash

while :
do
    clear
    cat<<EOF
    ==============================
     Dell iDRAC First Time Setup 
    ------------------------------
    Please enter your choice:
    Option (0) Setup Dell "RACADM"            (Prerequisite)
    Option (1) Setup NTP & TimeZone           (Verify ntpstatus.output file after execution)
    Option (2) View Current RAID Config       (Check raid.output file after execution)
    Option (3) Remove RAID Config             (Verify execution via Option-2)
    Option (4) Create RAID Config - Custom    (Verify execution via Option-2)
    Option (5) Create RAID Config - Identical (Verify execution via Option-2)
    Option (6) Configure BIOS                 (Verify bios.output file after execution)
    Option (7) View BIOS Settings             (Verify bios.output file after execution)
           (Q)uit
    ------------------------------

EOF
echo -e "\e[1;31mAfter any task selection from above options, below servers will be considered for selected operations as mentioned in iDRAC_Plan file.\e[0m"
cat iDRAC_Plan
echo "______________"
echo
echo "Please enter your option to proceed"
    read -n1 
    case "$REPLY" in
    "0")  sh racadm_install.sh;;
    "1")  sh iDRAC_NTP.sh;;
    "2")  sh iDRAC_RAIDview.sh ;;
    "3")  sh Remove_iDRAC_RAID.sh;;
    "4")  sh Create_iDRAC_RAID.sh ;;
    "5")  sh Identical_Create_iDRAC_RAID.sh;;
    "6")  sh iDRAC_set_BIOS.sh;;
    "7")  sh iDRAC_get_BIOS.sh;;
    "Q")  exit                      ;;
    "q")  echo "case sensitive!!"   ;; 
     * )  echo "invalid option"     ;;
    esac
    echo -e "\e[1;31mSelected Option-$REPLY have been completed. After 20 Seconds Main Menu will appear again for Other Options.\e[0m" 
    sleep 20
done


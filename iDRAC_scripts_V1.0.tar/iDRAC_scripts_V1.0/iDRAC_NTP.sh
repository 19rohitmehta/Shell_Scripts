#!/bin/bash
echo
echo -e "\e[1;31mWARNING : This script is strictly meant for first time NTP setup for iDRAC9 on Dell servers and override all existing NTP configuration. if mistakenly executed than please terminate the process immediately or contact Mavenir C0D team. Please make sure below all details are filled correctly.\e[0m"
echo
echo "Dell Server iDRAC IPs :-"
cat iDRAC_Plan
echo
echo "Enter iDRAC User Name (must be same for all iDRACs) :-"
read iDRAC_USER
echo "Enter $iDRAC_USER Password (must be same for all iDRACs) :-"
read iDRAC_PW
echo "Enter NTP IP-1 :-"
read NTP1
echo "Enter NTP IP-2 (Hit Enter if only one IP is being used as NTP ):-"
read NTP2
echo "Enter NTP IP-3 (Hit Enter if only one or two IPs are being used as NTP ):-"
read NTP3
echo "Enter TimeZone (Example Format :- Asia/Calcutta) :-"
read TimeZone
echo
while true; do
    read -p 'Please make sure above all details are correctly filled. Do you want to Continue? yes/no: ' input
    case $input in
        [yY]*)
            echo 'Continuing'
            break
            ;;
        [nN]*)
            echo 'Ok, exiting'
            exit 1
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
while read line; do
  iDRAC_IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"
  echo "Started NTP configuration for $iDRAC_IP"
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set idrac.NTPConfigGroup.ntp1 $NTP1 > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set idrac.NTPConfigGroup.ntp2 $NTP2 > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set idrac.NTPConfigGroup.ntp3 $NTP3 > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set idrac.time.timezone $TimeZone > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set idrac.NTPConfigGroup.NTPEnable Enabled > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set idrac.NTPConfigGroup.NTPMaxDist 16 > /dev/null 2>&1
done < "iDRAC_Plan"
echo
touch ntpstatus.output
true > ntpstatus.output

while read line; do
  iDRAC_IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"
  echo "Getting updated details for $iDRAC_IP..."
  echo "Below NTP has been set for iDRAC IP $iDRAC_IP" >> ntpstatus.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get idrac.NTPConfigGroup.ntp1 | egrep NTP1 >> ntpstatus.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get idrac.NTPConfigGroup.ntp2 | egrep NTP2 >> ntpstatus.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get idrac.NTPConfigGroup.ntp3 | egrep NTP3 >> ntpstatus.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get idrac.time.timezone | egrep Timezone >> ntpstatus.output
  echo "_______________________________________________________________________________________"  >> ntpstatus.output
  echo >> ntpstatus.output
  echo >> ntpstatus.output
done < "iDRAC_Plan"
echo
echo -e "\e[1;31mAll configurations have been completed. Request you to verify ntpstatus.output log file before you proceed further\e[0m."

#!/bin/bash
echo
echo -e "\e[1;31mWARNING : This script is strictly meant for first time BIOS setup for iDRAC9 on Dell servers and override all existing BIOS configuration. if mistakenly executed than please terminate the process immediately or contact Mavenir C0D team. Please make sure below all details are filled correctly.\e[0m"
echo
echo "Dell Server iDRAC IPs :-"
cat iDRAC_Plan
echo
echo "Enter iDRAC User Name (must be same for all iDRACs) :-"
read iDRAC_USER
echo "Enter $iDRAC_USER Password (must be same for all iDRACs) :-"
read iDRAC_PW
echo
while true; do
    read -p 'Please make sure above all details are correctly filled. Do you want to Continue? yes/no: ' input
    case $input in
        [yY]*)
            echo 'Continuing'
            break
            ;;
        [nN]*)
            echo 'Ok, exiting'
            exit 1
            ;;
         *)
            echo 'Invalid input' >&2
    esac
done
while read line; do
  iDRAC_IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"
  echo "Started BIOS configuration for $iDRAC_IP"
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set BIOS.BiosBootSettings.BootMode Bios  > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set BIOS.ProcSettings.ProcVirtualization Enabled > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set BIOS.ProcSettings.DcuStreamerPrefetcher Enabled > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set BIOS.ProcSettings.DcuIpPrefetcher Enabled > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set BIOS.ProcSettings.ProcHwPrefetcher Enabled > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.1.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.2.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.3.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.4.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.5.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.6.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.7.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.DeviceLevelConfig.8.VirtualizationMode SRIOV > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.1.LegacyBootProto PXE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.2.LegacyBootProto PXE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.3.LegacyBootProto NONE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.4.LegacyBootProto NONE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.5.LegacyBootProto NONE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.6.LegacyBootProto NONE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.7.LegacyBootProto NONE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW set NIC.NICConfig.8.LegacyBootProto NONE > /dev/null 2>&1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create BIOS.Setup.1-1 
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Slot.1-1-1 
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Slot.1-2-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Slot.4-1-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Slot.4-2-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Integrated.1-1-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Integrated.1-2-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Integrated.1-3-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW jobqueue create NIC.Integrated.1-4-1
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW serveraction hardreset
done < "iDRAC_Plan"
echo
touch bios.output
true > bios.output

while read line; do
  iDRAC_IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"
  echo "Getting updated details for $iDRAC_IP..."
  echo "Below BIOS config has been set for iDRAC IP $iDRAC_IP" >> bios.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get BIOS.BiosBootSettings.BootMode | egrep BootMode >> bios.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get BIOS.ProcSettings.ProcVirtualization | egrep ProcVirtualization >> bios.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get BIOS.ProcSettings.DcuStreamerPrefetcher | egrep DcuStreamerPrefetcher >> bios.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get BIOS.SysProfileSettings.ProcCStates | egrep ProcCStates  >> bios.output
  racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get BIOS.SysProfileSettings.ProcPwrPerf | egrep ProcPwrPerf  >> bios.output
  for i in 1 2 3 4 5 6 7 8; do racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get NIC.DeviceLevelConfig.$i.VirtualizationMode | egrep VirtualizationMode ; done >> bios.output
for i in 1 2 3 4 5 6 7 8; do racadm -r $iDRAC_IP -u $iDRAC_USER -p $iDRAC_PW get NIC.NICConfig.$i.LegacyBootProto | egrep LegacyBootProto ; done >> bios.output
  echo "_______________________________________________________________________________________"  >> bios.output
  echo >> bios.output
  echo >> bios.output
done < "iDRAC_Plan"
echo
echo -e "\e[1;31mAll configurations have been completed. Request you to verify bios.output log file before you proceed further\e[0m."

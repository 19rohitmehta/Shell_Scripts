import traceback
import pandas as pd
from collections import OrderedDict
import subprocess
import datetime
import ipaddress
import requests
import json
import urllib3
import sys

urllib3.disable_warnings()

def get_data(user, password , bcf_ip_address):

        print ("Started Fetching Chassis Details for BCF {}".format(bcf_ip_address))	
        data = { "user" : user, "password" : password }
        try:
            r = requests.post('https://{}:8443/api/v1/auth/login'.format(unicode(bcf_ip_address)),data=json.dumps(data),verify=False)
	    token = json.loads(r.text)['session_cookie']
	
	    headers = { 'Cookie' : 'session_cookie= ' + token }
	
	    response = requests.get('https://{}:8443/api/v1/data/controller/applications/bcf/info/fabric/connected-device'.format(unicode(bcf_ip_address)),verify=False,headers=headers)
	
	    j = json.loads(response.text)
            print ("Completed Fetching Chassis Details for BCF {}".format(bcf_ip_address))
            return j  
        except Exception as e:
            print(e.message)
            sys.exit(1)
            #traceback.print_exc()

def getPermanentMACAddress(dell_user, dell_pass, dell_server, bcf_data):
    ip_slot_mac_chasis_swith_interface = OrderedDict({})
    with open(dell_server) as df:
        for line in df:
            dell_ip = line.split(',')[0] 
            dell_hostname = line.split(',')[1] 
            #print(dell_ip)
            #print(dell_hostname)
            try:
                if ipaddress.IPv4Address(unicode(dell_ip.strip())) or ipaddress.IPv6Address(unicode(dell_ip.strip())):
                    cmd = 'python GetEthernetInterfacesREDFISH.py -ip {} -u {} -p {} -e y'.format(dell_ip.strip(), dell_user, dell_pass)
                    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
                    out, err = p.communicate() 
                    result = out.split('\n')
                    for nic_slot in result:
                       if nic_slot.startswith('NIC.Slot.'):
                           print ("Processing Dell Server : {} and NIC Slot : {}".format(dell_ip.strip(), nic_slot))
                           cmd1 = 'python GetEthernetInterfacesREDFISH.py -ip {} -u {} -p {} -d {}'.format(dell_ip.strip(), dell_user, dell_pass, nic_slot)
                           p1 = subprocess.Popen(cmd1, stdout=subprocess.PIPE, shell=True)
                           out1, err1 = p1.communicate()
                           result1 = out1.split('\n')
                           for perm_mac in result1:
                              if perm_mac.startswith('PermanentMACAddress'):
                                 perm_mac = perm_mac.split(':',1)[1].strip() 
                                 #print("Fetching Permanent MAC , Chassis, Interface and Switch for Dell Server : {} and NIC Slot : {}".format(dell_ip.strip(), nic_slot))
                                 #ip_slot_mac_chasis_swith_interface.update({dell_ip.strip()+nic_slot+perm_mac : ''})
                                 for i in bcf_data:
                                     if i.get('chassis-id') != None and i.get('chassis-id').upper()  == perm_mac.upper():
                                         #print('Chassis-id : {}'.format(i.get('chassis-id')))
                                         #print('Interface : {}'.format(i.get('interface')))
                                         #print('Switch : {}'.format(i.get('switch')))
                                         ip_slot_mac_chasis_swith_interface[dell_ip.strip()+nic_slot+perm_mac] = OrderedDict({"Server_IP": dell_ip.strip() ,"Hostname": dell_hostname.strip() , "NIC_Slot": nic_slot, 'MAC': perm_mac, 'chassis-id': i.get('chassis-id'), 'interface': i.get('interface'), 'switch':i.get('switch')})
            
            except Exception as e:
               print(e.message)
               #traceback.print_exc()
        #print(ip_slot_mac_chasis_swith_interface)
        return ip_slot_mac_chasis_swith_interface

if __name__ == '__main__':
     bcf_ip_address = raw_input("Enter BCF IP Address:")
     #bcf_ip_address = '10.69.33.110'
     bcf_user = raw_input("Enter BCF User Name:")
     #bcf_user = 'admin'
     bcf_pass = raw_input("Enter BCF Password:")
     #bcf_pass =  'mavenir'
     dell_servers = raw_input("Enter File Name with  Dell Server IPs:")
     #dell_servers = 'dell_servers'
     dell_user = raw_input("Enter Dell Server User:")
     #dell_user = 'root'
     dell_pass = raw_input("Enter Dell Server Password:")
     #dell_pass = 'mavenirserver'
     x = datetime.datetime.now()
     file_creation_time = x.strftime("%Y%m%d%H%M%S%f")
     bcf_data = 'YetToGetValue'
     try:
         if ipaddress.IPv4Address(unicode(bcf_ip_address.strip())) or ipaddress.IPv6Address(unicode(bcf_ip_address.strip())):
             bcf_data = get_data(bcf_user, bcf_pass, bcf_ip_address.strip())
     except Exception as e:
         print(e.message)
         #traceback.print_exc()
         print("Invalid BCF IP Address")
     
     ip_slot_mac_chasis_swith_interface = getPermanentMACAddress(dell_user, dell_pass, dell_servers, bcf_data)
  
     print("Writing data to result_{}.csv".format(file_creation_time))
     try:
          df = pd.DataFrame()
          df.to_csv("result_{}.csv".format(file_creation_time))
          header_flag = 'True' 
          for entry in ip_slot_mac_chasis_swith_interface:
              output_df = pd.Series(ip_slot_mac_chasis_swith_interface[entry]['Server_IP'])
              output_df = output_df.reset_index().rename(columns={output_df.index.name: 'index'})
              output_df = output_df.rename(columns={output_df.columns[1]: "Server"}) 
              output_df['Hostname'] = ip_slot_mac_chasis_swith_interface[entry]['Hostname']
              output_df['Slot'] = ip_slot_mac_chasis_swith_interface[entry]['NIC_Slot']
              output_df['MAC'] = ip_slot_mac_chasis_swith_interface[entry]['MAC']
              output_df['Chassis-id'] = ip_slot_mac_chasis_swith_interface[entry]['chassis-id']
              output_df['Switch'] = ip_slot_mac_chasis_swith_interface[entry]['switch']
              output_df['Interface Name'] = ip_slot_mac_chasis_swith_interface[entry]['interface']
              output_df = output_df.drop('index', 1)
              if header_flag == 'True':
                  output_df = output_df.to_csv("result_{}.csv".format(file_creation_time), index=False, header=True)
                  header_flag = 'False'
              else:
                  output_df = output_df.to_csv("result_{}.csv".format(file_creation_time), mode='a', index=False, header=False)
          print("Result is stored to result_{}.csv".format(file_creation_time))
     except Exception as e:
         print(e.message)
         #traceback.print_exc()
         print("Error occured while writing data to csv file")
          


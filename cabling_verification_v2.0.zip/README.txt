To run the script :

>> python script.py 
Note: Use python 2.7

Script will ask for below inputs :
++++++++++++++++++++++++++++++++
1) BCF Server IP Address
2) BCF Server User
3) BCF Server Password
4) File Name with  Dell Server IPs ( Put the IP address in lines)
5) Dell Server User
6) Dell Server Password

Output :
++++++++
Result will be generated in script directory with name : result_{file_creation_time}.csv

Note: In case any Dell server is not reachable , default timeout in 120 Seconds. After that script will continue with next dell server in file.

prerequisite :

pip install requests pandas



To run the script :

>> python script.py <Input Text file>

Example:
python script_feb112021.py input.txt

Where input.txt must include the credentials of bcf and also number of compute slots
This input.txt will be input for both Scripts ie., BCF Script File, Cabling Script File

So please enter the BCF credentials in the input.txt file

Note: Use python 2.7

Script will ask for below inputs :
++++++++++++++++++++++++++++++++
1) BCF Server IP Address (taken from input file)
2) BCF Server User (taken from input file)
3) BCF Server Password  (taken from input file)
4) File Name with  Dell Server IPs ( Put the IP address in lines)
5) Dell Server User
6) Dell Server Password

Output :
++++++++
Result will be generated in script directory with name : node_result_{file_creation_time}.csv

Example :
compute_result_20210201062213427342.csv
controller_storage_result_20210201062213427342.csv

Note: In case any Dell server is not reachable , default timeout in 120 Seconds. After that script will continue with next dell server in file.

prerequisite :

pip install requests pandas

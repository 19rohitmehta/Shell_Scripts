__author__ = "NaveeN"

import sys
import os
import pdb
import json
import datetime
import logging
import requests
import urllib3


class TriggerInterfaceCreation:
    def __init__(self):
        self.report_dir = '/root/openstack/cabling_verification_v2.0/bcf_config_script/Report/'
        self.expected_string = 'NIC.Slot.1'
        self.compute_start_str = 'compute'
        self.controller_storage_start_str = 'controller_storage'
        self.controller_storage_slots = 4  # fixed slots
        self.input_file1_columns = 7  # sys.argv[1]
        self.input_file2_columns = 5
        self.final_compute_list = {}  # list of compute server ips with hostnames
        self.final_ctrl_list = {}  # list of compute server ips with hostnames
        #pdb.set_trace()
        self.setup_logging()
        self.validation_1()

        for node in (self.compute, self.controller_storage):
            self.validation(node)
            self.bcf_credentials = {"user": self.credentials['bcf_username'], "password": self.credentials['bcf_password']}

            # interface configuration
            self.user_input = raw_input("\n** All Checks Done, PLEASE WRITE 'yes' TO CONTINUE TO '{}' INTERFACE "
                                        "CONFIGURATION\nINPUT: ".format(node))
            self.logger.log(logging.INFO, "\n** All Checks Done, PLEASE WRITE 'yes' TO CONTINUE TO '{}' INTERFACE "
                                          "CONFIGURATION\nINPUT: ".format(node) + self.user_input)
            if node == self.compute:
                self.intf_compute_config()
            elif node == self.controller_storage:
                self.intf_ctrl_storage_config()
            print("Interface Configuration for '{}' Done".center(60, '*').format(node)+'\n\n')
            self.logger.log(logging.INFO, "Interface Configuration Done".center(70, '*')+'\n\n')

        # layer-2/3 configuration
        for node in (self.compute, self.controller_storage):
            self.layer2_3_config(node)
        self.final_l2_l3_config()

        logging.shutdown()

    def intf_compute_config(self):
        try:
            if self.user_input == 'yes':
                urllib3.disable_warnings()
                response_1 = requests.post('https://{}:8443/api/v1/auth/login'.format(self.credentials['bcf_ip']),
                                            data=json.dumps(self.bcf_credentials), verify=False)
                token = json.loads(response_1.text)['session_cookie']
                if token:
                    headers = {'Cookie': 'session_cookie= ' + token}
                else:
                    print("Token not Found for the IP-{}".format(self.credentials['bcf_ip']))
                    self.logger.log(logging.ERROR, "Token not Found for the IP-{}".format(self.credentials['bcf_ip']))
                    exit()

                for ip in self.data_dict:
                    hostnames_list = []
                    print("\n\n#For IP - {}\n".format(ip))
                    self.logger.log(logging.INFO, "\n\n#For IP - {}\n".format(ip))
                    # for the expected string take two interfaces and remaining only one intf
                    count = 0
                    for hostname, slot, switch, intf in zip(self.data_dict[ip]['hostnames'],
                                                                self.data_dict[ip]['slots'], self.data_dict[ip]
                                                            ['switches'], self.data_dict[ip]['intfs']):
                        if self.expected_string in slot:
                            if count == 0:
                                intgrp = {'name': hostname + '_bond0', 'mode': 'lacp',
                                            'member-interface': [({"interface-name": intf, "switch-name": switch})]}
                            elif count == 1:
                                intgrp['member-interface'].append(({"interface-name": intf, "switch-name": switch}))
                            count += 1
                            if count == 2:
                                hostnames_list.append(intgrp['name'])
                                self.final_compute_list[ip] = hostnames_list
                                print(json.dumps(intgrp))
                                self.logger.log(logging.INFO, json.dumps(intgrp))

                                response_2 = requests.post(
                                    'https://{}:8443/api/v1/data/controller/applications/bcf/interface-group'.format
                                    (self.credentials['bcf_ip']), data=json.dumps(intgrp), verify=False, headers=headers)
                                print('Response: '+response_2.text+'\n')
                                self.logger.log(logging.DEBUG, 'Response: '+response_2.text+'\n')
                                count = 0
                        else:
                            intgrp1 = {'name': hostname+'_'+slot,
                                        'member-interface': [({"interface-name": intf, "switch-name": switch})]}
                            print(json.dumps(intgrp1))
                            self.logger.log(logging.INFO, json.dumps(intgrp1))
                            hostnames_list.append(intgrp1['name'])
                            self.final_compute_list[ip] = hostnames_list

                            response_2 = requests.post(
                                'https://{}:8443/api/v1/data/controller/applications/bcf/interface-group'.format(
                                        self.credentials['bcf_ip']), data=json.dumps(intgrp), verify=False, headers=headers)
                            print('Response: '+response_2.text+'\n')
                            self.logger.log(logging.DEBUG, 'Response: '+response_2.text+'\n')
                #print('#output of intf config\n'+str(self.final_compute_list)+'\n')
                self.logger.log(logging.DEBUG, '#output of intf config\n'+str(self.final_compute_list)+'\n')
            else:
                print("Exiting without BCF Configuration!")
                self.logger.log(logging.DEBUG, "Exiting without BCF Configuration!")
                exit()
        except Exception as ex:
            print(ex)
            self.logger.log(logging.ERROR, ex)
            exit()

    def intf_ctrl_storage_config(self):
        try:
            if self.user_input == 'yes':
                urllib3.disable_warnings()
                response_1 = requests.post('https://{}:8443/api/v1/auth/login'.format(self.credentials['bcf_ip']),
                                            data=json.dumps(self.bcf_credentials), verify=False)
                token = json.loads(response_1.text)['session_cookie']
                if token:
                    headers = {'Cookie': 'session_cookie= ' + token}
                else:
                    print("Token not Found for the IP-{}".format(self.credentials['bcf_ip']))
                    self.logger.log(logging.ERROR, "Token not Found for the IP-{}".format(self.credentials['bcf_ip']))
                    exit()

                for ip in self.data_dict:
                    hostnames_list = []
                    print("\n\n#For IP - {}\n".format(ip))
                    self.logger.log(logging.INFO, "\n\n#For IP - {}\n".format(ip))
                    # for the expected string take two interfaces and remaining only one intf
                    count = 0
                    count1 = 0
                    for hostname, slot, switch, intf in zip(self.data_dict[ip]['hostnames'],
                                                            self.data_dict[ip]['slots'], self.data_dict[ip]
                                                            ['switches'], self.data_dict[ip]['intfs']):
                        bond_list = self.return_bond_list(ip)
                        if slot in bond_list[0]:  # bond0
                            if count == 0:
                                intgrp = {'name': hostname + '_bond0', 'mode': 'lacp',
                                            'member-interface': [({"interface-name": intf, "switch-name": switch})]}
                            elif count == 1:
                                intgrp['member-interface'].append(({"interface-name": intf, "switch-name": switch}))
                            count += 1
                            if count == 2:
                                hostnames_list.append(intgrp['name'])
                                self.final_ctrl_list[ip] = hostnames_list
                                print(json.dumps(intgrp))
                                self.logger.log(logging.INFO, json.dumps(intgrp))

                                response_2 = requests.post(
                                    'https://{}:8443/api/v1/data/controller/applications/bcf/interface-group'.format
                                    (self.credentials['bcf_ip']), data=json.dumps(intgrp), verify=False, headers=headers)
                                print('Response: '+response_2.text+'\n')
                                self.logger.log(logging.DEBUG, 'Response: '+response_2.text+'\n')

                                count = 0
                        else:
                            if count1 == 0:
                                intgrp1 = {'name': hostname+'_bond1', 'mode': 'lacp',
                                            'member-interface': [({"interface-name": intf, "switch-name": switch})]}
                            elif count1 == 1:
                                    intgrp1['member-interface'].append(({"interface-name": intf, "switch-name": switch}))
                            count1 += 1
                            if count1 == 2:
                                hostnames_list.append(intgrp1['name'])
                                self.final_ctrl_list[ip] = hostnames_list
                                print(json.dumps(intgrp1))
                                self.logger.log(logging.INFO, json.dumps(intgrp1))

                                response_2 = requests.post(
                                    'https://{}:8443/api/v1/data/controller/applications/bcf/interface-group'.format(
                                            self.credentials['bcf_ip']), data=json.dumps(intgrp1), verify=False, headers=headers)
                                print('Response: '+response_2.text+'\n')
                                self.logger.log(logging.DEBUG, 'Response: '+response_2.text+'\n')

                                count1 = 0
                #print('#output of intf config\n' + str(self.final_ctrl_list) + '\n')
                self.logger.log(logging.DEBUG, '#output of intf config\n' + str(self.final_ctrl_list) + '\n')
            else:
                print("Exiting without BCF Configuration!")
                self.logger.log(logging.DEBUG, "Exiting without BCF Configuration!")
                exit()
        except Exception as ex:
            print(ex)
            self.logger.log(logging.ERROR, ex)
            exit()

    def layer2_3_config(self, node):
        if node == self.compute:  # execute only once
            self.option = raw_input("DO YOU WANT LAYER2/LAYER3 CONFIGURATION ?? If yes, Please write 'yes' \nINPUT: ")
            self.logger.log(logging.INFO, "DO YOU WANT LAYER2/LAYER3 CONFIGURATION ?? ?? If yes, Please write 'yes' "
                                           "\nINPUT: " + self.option)
            if self.option == 'yes':  #  # 'sample_input_original_copy.csv'
                self.input_file2 = raw_input("PLEASE WRITE INPUT CSV FILE NAME FOR Tenants/VLAN\nINPUT: ")
                self.logger.log(logging.INFO, "PLEASE WRITE INPUT CSV FILE NAME FOR Tenants/VLAN\nINPUT: " +
                                self.input_file2 + '\n')
                if not os.path.isfile(self.input_file2):
                    print("Given Input csv File - '{}' does not exist! please check".format(self.input_file2))
                    self.logger.log(logging.ERROR, "Given Input csv File - '{}' does not exist! please check"
                                    .format(self.input_file2))
                    exit()
                if not self.input_file2.endswith('.csv'):
                    print("Error: Invalid Input...Please provide valid input file(file name ends with .csv)")
                    self.logger.log(logging.ERROR, "Error: Invalid Input...Please provide valid input file"
                                                   "(file name must end with .csv)")
                    exit()
            else:
                print("Skipping Layer2-3 Configuration")
                self.logger.log(logging.INFO, "Skipping Layer2-3 Configuration")
                exit()
            print('\n')
            # validate the csv file
            print("Validating Input CSV File\n")
            self.logger.log(logging.INFO, "Validating Input CSV File\n")
            self.validate_columns(self.input_file2, self.input_file2_columns)
        # interface configure
        if self.option == 'yes':
            if node == self.compute:
                self.layer2_3_compute_configure()
            else:
                self.layer2_3_ctrl_configure()

    def layer2_3_compute_configure(self):
        try:
            print('\n***Layer-2 & 3 Configuration***\n')
            self.logger.log(logging.INFO, '\n***Layer-2 & 3 Configuration***\n')

            final_data = []
            tenants = []
            with open(self.input_file2) as csv:
                for line in csv.readlines():  # tenants line
                    segment_list = []
                    tenant_info_list = []
                    _segment_list = []
                    _tenant_info_list = []

                    if "VRF/Tenant_Name,VLAN_NAME,Vlan_ID" in line:
                        continue
                    line_split = line.strip().split(',')

                    tenant, vlan_name, vlan_id, ipv4_ip, ipv6_ip = line_split[0], line_split[1], line_split[2], \
                                                                   line_split[3], line_split[4]
                    # output file
                    ipv4_ipv6_count = 0
                    for ip, val in self.final_compute_list.items():
                        for name in val:
                            if 'Openstack' in tenant and 'bond0' in name:
                                # segment
                                segment_list.append(self.segment(vlan_id, vlan_name, name))
                                # tenant_info
                                if ipv4_ip != 'none' and ipv6_ip == 'none':  # only ipv4
                                    _tenant_info = self.tenant_info(ipv4_ip, vlan_name)
                                    if _tenant_info not in tenant_info_list:  # add only one
                                        tenant_info_list.append(_tenant_info)
                                if ipv4_ip == 'none' and ipv6_ip != 'none':  # only ipv6
                                    _tenant_info = self.tenant_info(ipv6_ip, vlan_name)
                                    if _tenant_info not in tenant_info_list:  # add only one
                                        tenant_info_list.append(_tenant_info)
                                if ipv4_ip != 'none' and ipv6_ip != 'none':  # both
                                    if ipv4_ipv6_count == 0:
                                        _tenant_info = self.tenant_info(ipv4_ip, vlan_name)
                                        if _tenant_info not in tenant_info_list:  # add only one
                                            tenant_info_list.append(_tenant_info)
                                        _tenant_info['ip-subnet'].append(
                                            {"directed-broadcast": False, "no-autoconfig": False, 'ip-cidr': ipv6_ip,
                                             "withdraw": False})  # add ipv6 address
                                        ipv4_ipv6_count += 1

                                break
                            elif 'Openstack' not in tenant and 'bond0' not in name:
                                # segment
                                _segment_list.append(self.segment(vlan_id, vlan_name, name))
                                # tenant_info
                                if ipv4_ip != 'none' and ipv6_ip == 'none':  # only ipv4
                                    _tenant_info = self.tenant_info(ipv4_ip, vlan_name)
                                    if _tenant_info not in _tenant_info_list:  # add only one
                                        _tenant_info_list.append(_tenant_info)
                                if ipv4_ip == 'none' and ipv6_ip != 'none':  # only ipv6
                                    _tenant_info = self.tenant_info(ipv6_ip, vlan_name)
                                    if _tenant_info not in _tenant_info_list:  # add only one
                                        _tenant_info_list.append(_tenant_info)
                                if ipv4_ip != 'none' and ipv6_ip != 'none':  # both
                                    if ipv4_ipv6_count == 0:
                                        _tenant_info = self.tenant_info(ipv4_ip, vlan_name)
                                        if _tenant_info not in _tenant_info_list:  # add only one
                                            _tenant_info_list.append(_tenant_info)
                                        _tenant_info['ip-subnet'].append(
                                            {"directed-broadcast": False, "no-autoconfig": False,'ip-cidr': ipv6_ip,
                                             "withdraw": False})  # add ipv6 address
                                        ipv4_ipv6_count += 1

                    if 'Openstack' in tenant and 'bond0' in name:
                        list1, list2 = segment_list, tenant_info_list
                    elif 'Openstack' not in tenant and 'bond0' not in name:
                        list1, list2 = _segment_list, _tenant_info_list
                    if tenant not in tenants:
                        final_data.append(self.single_tenant(tenant, list1, list2, vlan_name))
                        tenants.append(tenant)
                    else:
                        for data in final_data:
                            if data:
                                if data['name'] == tenant:
                                    final_data.append(self.existing_tenant(data, vlan_name, list1, list2))
                                    break
            # remove None
            self.compute_final_data = filter(None, final_data)  # use list() for python3

        except Exception as ex:
            print(ex)
            self.logger.log(logging.ERROR, ex)
            exit()

    def layer2_3_ctrl_configure(self):
        try:
            final_data = []
            tenants = []

            with open(self.input_file2) as csv:
                for line in csv.readlines():  # tenants line
                    segment_list = []
                    tenant_info_list = []

                    if "VRF/Tenant_Name,VLAN_NAME,Vlan_ID" in line:
                        continue
                    line_split = line.strip().split(',')
                    tenant, vlan_name, vlan_id, ipv4_ip, ipv6_ip = line_split[0], line_split[1], line_split[2], \
                                                                   line_split[3], line_split[4]
                    # output file
                    ipv4_ipv6_count = 0

                    for ip, val in self.final_ctrl_list.items():
                        for name in val:
                            if 'Openstack' in tenant:
                                # segment
                                segment_list.append(self.segment(vlan_id, vlan_name, name))
                                # tenant_info
                                if ipv4_ip != 'none' and ipv6_ip == 'none':  # only ipv4
                                    _tenant_info = self.tenant_info(ipv4_ip, vlan_name)
                                    if _tenant_info not in tenant_info_list:  # add only one
                                        tenant_info_list.append(_tenant_info)
                                if ipv4_ip == 'none' and ipv6_ip != 'none':  # only ipv6
                                    _tenant_info = self.tenant_info(ipv6_ip, vlan_name)
                                    if _tenant_info not in tenant_info_list:  # add only one
                                        tenant_info_list.append(_tenant_info)
                                if ipv4_ip != 'none' and ipv6_ip != 'none':  # both
                                    if ipv4_ipv6_count == 0:
                                        _tenant_info = self.tenant_info(ipv4_ip, vlan_name)
                                        if _tenant_info not in tenant_info_list:  # add only one
                                            tenant_info_list.append(_tenant_info)
                                        _tenant_info['ip-subnet'].append(
                                            {"directed-broadcast": False, "no-autoconfig": False,
                                             'ip-cidr': ipv6_ip, "withdraw": False})  # add ipv6 address
                                        ipv4_ipv6_count += 1

                                #break
                    if 'Openstack' in tenant:
                        if tenant not in tenants:
                            final_data.append(self.single_tenant(tenant, segment_list, tenant_info_list, vlan_name))
                            tenants.append(tenant)
                        else:
                            for data in final_data:
                                if data:
                                    if data['name'] == tenant:
                                        final_data.append(self.existing_tenant(data, vlan_name, segment_list,
                                                                               tenant_info_list))
                                        break
            # remove None
            self.ctrl_final_data = filter(None, final_data)  # use list() for python3

        except Exception as ex:
            print(ex)
            self.logger.log(logging.ERROR, ex)
            exit()

    def final_l2_l3_config(self):
        try:
            for i in self.ctrl_final_data[0]['segment']:
                for c in self.compute_final_data:
                    for j in c['segment']:
                        if j['name'] == i['name']:
                            for _i in i['interface-group-membership-rule']:
                                #if _i not in j["interface-group-membership-rule"]:
                                j["interface-group-membership-rule"].append(_i)

            # save the config in config file
            with open(self.log_dir_date + "/json_config_"+self.today_date+'_'+self.time_now+'.json', "w") as outfile:
                json.dump(self.compute_final_data, outfile, indent=3)

            # configure to the devices
            urllib3.disable_warnings()
    
            response_1 = requests.post('https://{}:8443/api/v1/auth/login'.format(self.credentials['bcf_ip']),
                                       data=json.dumps(self.bcf_credentials), verify=False)
            token = json.loads(response_1.text)['session_cookie']
            if token:
                headers = {'Cookie': 'session_cookie= ' + token}
            else:
                print("Token not Found for the IP-{}".format(self.credentials['bcf_ip']))
                self.logger.log(logging.ERROR, "Token not Found for the IP-{}".format(self.credentials['bcf_ip']))
                exit()
    
            with open(self.log_dir_date + "/json_config_"+self.today_date+'_'+self.time_now+'.json') as json_file:
                json_tenant = json.load(json_file)
    
            response_1 = requests.post('https://{}:8443/api/v1/data/controller/applications/bcf/tenant'
                                      .format(self.credentials['bcf_ip']), json=json_tenant, verify=False,
                                       headers=headers)
            print('Response: ' + response_1.text)
            self.logger.log(logging.DEBUG, 'Response: ' + response_1.text)

            print('\n')
            print("Layer2/3 Configurations Done!".center(50, '-'))
        except Exception as ex:
            print(ex)
            self.logger.log(logging.ERROR, ex)
            exit()

    def return_bond_list(self, ip):
        bond0_list, bond1_list = [], []
        for slot, host, switch, intf in zip(self.data_dict[ip]['slots'], self.data_dict[ip]['hostnames'],
                                                self.data_dict[ip]['switches'], self.data_dict[ip]['intfs']):
            if 'NIC.Slot.1-1-1' == slot or self.expected_string not in slot and slot.split('-')[1] == '2':
                bond0_list.append(slot)
            else:
                bond1_list.append(slot)
        return bond0_list, bond1_list

    def single_tenant(self, tenant, segments, tenant_infos, vlan_name):
        data = {'segment': [{'interface-group-membership-rule': segments, 'name': vlan_name}],
                'name': tenant,
                'logical-router':
                    {'segment-interface': tenant_infos}
                }
        return data

    def existing_tenant(self, data, vlan_name, segments, tenant_infos):
        data['segment'].append({'interface-group-membership-rule': segments, 'name': vlan_name})
        for _tenant in tenant_infos:
            data['logical-router']['segment-interface'].append(_tenant)

    def segment(self, vlan_id, vlan_name, name):
        segment_dict = {'interface-group': name, 'vlan': vlan_id, 'virtual': False,'preserve-vlan': False}
        return segment_dict

    def tenant_info(self, l3_ip, vlan_name):
        tenant_info = {'ip-subnet': [{"directed-broadcast": False, "no-autoconfig": False, 'ip-cidr': l3_ip,
                                      "withdraw": False}], 'segment': vlan_name, 'shutdown': False}
        return tenant_info

    def get_data(self, file_name):
        with open(file_name) as csv:
            self.data_dict = {}
            ips, hostnames, slots, macs, chassises, switches, intfs = [], [], [], [], [], [], []

            for line in csv.readlines():
                if "Server,Hostname,Slot,MAC,Chassis-id,Switch,Interface" in line:
                    continue
                line_split = line.strip().split(',')
                ip, hostname, slot, mac, chassis, switch, intf = line_split[0], line_split[1], line_split[2], \
                                                                 line_split[3], line_split[4], line_split[5], \
                                                                 line_split[6]
                if ip not in self.data_dict:
                    ips, hostnames, slots, macs, chassises, switches, intfs = [], [], [], [], [], [], []
                ips.append(ip)
                hostnames.append(hostname)
                slots.append(slot)
                macs.append(mac)
                chassises.append(chassis)
                switches.append(switch)
                intfs.append(intf)
                self.data_dict[ip] = {'hostnames': hostnames, 'slots': slots, 'macs': macs,
                                 'chassises': chassises, 'switches': switches, 'intfs': intfs}

    def setup_logging(self):
        """
         1. Create a Logs directory if not present
         2. Create a Directory with Current Date if not present
         3. Create a Directory with Current Time if not present
          Put the file here
          should be like /root/Report/date/time/
        """

        # should be like /root/Logs/date/time/
        self.today_date = datetime.datetime.now().strftime('%d-%m-%Y')
        self.time_now = datetime.datetime.now().strftime('%H-%M-%S')

        log_dir = self.report_dir
        self.log_dir_date = log_dir + self.today_date

        # create a Logs directory if not present
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            os.chmod(log_dir, 777)

        # create a Directory with Current Date if not present
        if not os.path.exists(self.log_dir_date):
            os.makedirs(self.log_dir_date)
            os.chmod(self.log_dir_date, 777)

        _formatter = logging.Formatter("%(message)s")
        self.logger = logging.getLogger("NaveeN")
        self.logger.setLevel(logging.DEBUG)

        # should be like /root/Logs/date/time/result_202001181311002.txt
        # ex : /root/Logs/2019-10-22/08-44-45

        # self.logger.log on screen
        #console_handler = logging.StreamHandler()
        file_handler = logging.FileHandler(self.log_dir_date + '/result_'+self.today_date+'_'+self.time_now+'.txt')
        file_handler.setFormatter(_formatter)
        #self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)
        return True

    def validation(self, node):
        if node == self.compute:  # which means execute only one time
            print("***Running for Compute Logic***\n")
            self.logger.log(logging.INFO, "***Running for Compute Logic***")
        else:
            print("***Running for Controller/Storage Logic***\n")
            self.logger.log(logging.INFO, "***Running for Controller/Storage Logic***")

        # validation-2 - validate number of columns in a csv file
        self.validate_columns(node, self.input_file1_columns)
        print("Validation-2: {} columns in a csv file-'{}' Verified".format(self.input_file1_columns, node))
        self.logger.log(logging.INFO,
                        "Validation-2: {} columns in a csv file Verified".format(self.input_file1_columns))
        # Remaining 3 validations
        self.get_data(node)

        for ip in self.data_dict:
            # validation-3 - no. of slots should match the "slot input number"
            unique_slots = []
            controller_slots = []
            for slot in self.data_dict[ip]['slots']:
                if slot not in controller_slots:  # controller logic
                    controller_slots.append(slot)
                slot_split = slot.split('-')  # compute logic
                if slot_split[0] not in unique_slots:
                    unique_slots.append(slot_split[0])
            # self.logger.log(unique_slots)
            count = 0
            if node == self.compute:
                if len(unique_slots) == int(self.credentials['compute_slots']):
                    print("\nValidation-3: No. of Slots Verified for the IP-{} ({})".format(ip, node))
                    self.logger.log(logging.INFO, "\nValidation-3: No. of Slots Verified for the IP-{} ({})".format(ip, node))
                    count = 1
            elif node == self.controller_storage:
                if len(controller_slots) == self.controller_storage_slots:
                    print("\nValidation-3: No. of Slots Verified for the IP-{} ({})".format(ip, node))
                    self.logger.log(logging.INFO, "\nValidation-3: No. of Slots Verified for the IP-{} ({})".format(ip, node))
                    count = 1
            if not count:
                print("\nValidation-3: ERROR.. Since No. of Slots Mismatched with given slots for the IP-{} ({})"
                      .format(ip, node))
                self.logger.log(logging.ERROR, "\nValidation-3: ERROR.. Since No. of Slots Mismatched with given "
                                               "slots for the IP - {} ({})".format(ip, node))
                exit()
            # validation-4 - Check if ip has "NIC.Slot.1"
            for slot in self.data_dict[ip]['slots']:
                if self.expected_string in slot:
                    print("Validation-4: '{}' Verified for the IP-{} ({})".format(self.expected_string, ip, node))
                    self.logger.log(logging.INFO, "Validation-4: '{}' Verified for the IP-{} ({})".
                                    format(self.expected_string, ip, node))
                    break
            else:
                print("Validation-4: ERROR..'{}' Not found for the IP-{} ({})".format(self.expected_string, ip, node))
                self.logger.log(logging.ERROR, "Validation-4: ERROR..'{}' Not found for the IP-{} ({})".
                                format(self.expected_string, ip, node))
                exit()

            # validation-5 - Check that slot column has 2 interfaces for "NIC.Slot.1"
            count = 0
            for slot in self.data_dict[ip]['slots']:
                if self.expected_string in slot:
                    count += 1
            if count == 2:
                print("Validation-5: Slot '{}' has two intfs Verified for the IP-{} ({})"
                      .format(self.expected_string, ip, node))
                self.logger.log(logging.INFO, "Validation-5: Slot '{}' has two intfs Verified for the IP-{} ({})".
                                format(self.expected_string, ip, node))
            else:
                print("Validation-5: ERROR.. Since Slot '{}' has {} intfs for the IP-{} ({})"
                      .format(self.expected_string, count, ip, node))
                self.logger.log(logging.ERROR, "Validation-5: ERROR.. Since Slot '{}' has {} intfs for the IP-{} ({})".
                                format(self.expected_string, count, ip, node))
                exit()

    def validate_columns(self, filename, columns):
        with open(filename) as csv:
            for line in csv.readlines():
                line_split = line.strip().split(',')
                given_columns = []
                for split in line_split:
                    if split != '':
                        given_columns.append(split)
                if len(given_columns) != columns:
                    print("Error: Found {} Entries in line - '{}'\nIt should be 7".
                          format(len(given_columns), line.strip()))
                    self.logger.log(logging.ERROR, "Error: Found {} Entries in line - '{}'\nIt should be {}".
                                    format(len(given_columns), line.strip(), columns))
                    exit()

    def validation_1(self):
        # Check argument ie compute_result_file.csv or controller_storage_result_file.csv
        if len(sys.argv) == 1:
            print("Error: Invalid number of arguments...Please provide one input-file")
            self.logger.log(logging.ERROR, "Error: Please provide one input-file")
            exit()

        elif len(sys.argv) > 2:
            print("Error: Invalid number of arguments...only one input is required!")
            self.logger.log(logging.ERROR, "Error: only one input is required!")
            exit()

        # validate input file
        if not os.path.isfile(sys.argv[1]):
            print("Given Input csv File - '{}' does not exist! please check".format(sys.argv[1]))
            self.logger.log(logging.ERROR, "Given Input File - '{}' does not exist! please check"
                                .format(sys.argv[1]))
            exit()

        self.compute = raw_input("Please provide compute file name: ")  # 'compute_result_file.csv'
        self.controller_storage = raw_input("Please provide controller_storage file name: ")
        # 'controller_storage_result_file.csv'

        self.node = ''
        for file_name, str_name in zip((self.compute, self.controller_storage),
                                       (self.compute_start_str, self.controller_storage_start_str)):
            if not os.path.isfile(file_name):
                print("Given Input csv File - '{}' does not exist! please check".format(file_name))
                self.logger.log(logging.ERROR, "Given Input csv File - '{}' does not exist! please check"
                                .format(file_name))
                exit()

            if not file_name.startswith(str_name) or not file_name.endswith('.csv'):
                print("Error: Invalid Input...Please provide valid input file(file name should starts with {} and "
                      "ends with .csv)".format(str_name))
                self.logger.log(logging.ERROR, "Error: Invalid Input...Please provide valid input file(file name "
                                               "should starts with {} and ends with .csv)"
                                .format(str_name))
                exit()

        # take the bcf inputs from user file
        self.credentials = {}
        reserve_params = ('bcf_ip', 'bcf_username', 'bcf_password', 'compute_slots')
        with open(sys.argv[1]) as input_file:
            for line in input_file.readlines():
                line_split = line.split('=')
                if line_split[0].strip() not in reserve_params:
                    print("Invalid Input Parameter-'{}' in the File - {}".format(line_split[0], sys.argv[1]))
                    self.logger.log(logging.ERROR, "Invalid Input Parameter-'{}' in the File - {}"
                                    .format(line_split[0], sys.argv[1]))
                    exit()
                self.credentials[line_split[0].strip()] = line_split[1].strip()
        if not self.credentials['compute_slots'].isdigit():
            print("Error: Please provide valid digit in the input file - {}".format(sys.argv[1]))
            self.logger.log(logging.ERROR, "Error: Please provide valid digit in the input file - {}"
                            .format(sys.argv[1]))
            exit()

        print("\nValidation-1: Input arguments Verified\n")
        self.logger.log(logging.INFO, "Validation-1: Input arguments Verified")


bcf_config = TriggerInterfaceCreation()


*** This Script configures both Compute and Controller/Stroage BCF Interface & Layer2/Layer3 Configurations  ***

NOTE: 
Before running the script make sure pushing configuration should not be configured earlier else script will not configure.
Example:
Assume its already Openstack_Test configuration is their but Script pushing configurations of tenants Openstack_Test,cnm and IMS_VOLTE.
So in this case Script doesn't work! So to make it to work, you should delete the Openstack_Test in the device then Execute the Script.

(Package contains Script File, Input File and README )

# Execution method

Python Version used: Python2.7.X

Execution method:
python <scriptname> <Input Text file>

Example:
python trigger_interface_creation.py input.txt

Where input.txt must include the credentials of bcf and also number of compute slots



# Few important points to noted before running the script

* Must Have 1 Input argument from commandline
* Three inputs taken from user
1. compute_result_file.csv    --- For compute (This file is generated from the cabling script for compute server ips)
2. controller_storage_result_file.csv --- For controller/storage  (This file is generated from the cabling script for controller/storage server ips)

For compute file, file name must start with 'compute' and ends with '.csv'
For controller/storage file, file name must start with 'controller_storage' and ends with '.csv'

Note: 
- Above files (compute & ctrl file) must have 7 columns
- If any entry is blank then it validation fails as a result it throws the ERROR  

3. input_tenants_vlan_file.csv  --- Tenants/Vlan CSV input for Layer2/Layer3 configuration

Where Tenants/Vlan CSV input file having the Layer2/Layer3 inputs such as Tenants, Vlan names, vlan_id, ipv4 and ipv6 ip

Note: 
- This file(Tenants/Vlan CSV input) must have 5 columns  
- If any entry is blank then fill as 'none' otherwise it throws the ERROR


* Once the script ran, Script generates the result_DATE_TIME.txt and json_config_DATE_TIME.json files under Report/Current_Date/

Where 
result_DATE_TIME.txt 		-- > Log of entire script
json_config_DATE_TIME.json  -- > Config File of Compute and Controller configuration




#How the Script Works 

Step 1: Validate Number of arguments and validation of the given inputs (Validation-1)

Step 2: Validation of Compute File CSV File

Validation-2 - validate number of columns in a csv file
Validation-3: No. of Slots Verified for the Given Server IP(which is given in the csv file)
Validation-4: Check if server ip has "NIC.Slot.1"
Validation-5 - Check that slot column has 2 interfaces for "NIC.Slot.1"

Step 3: Prompts to user to allow the interface configuration of Compute using api
In this Step, Script Configures the Compute Interface Configurations

Step 4: Repeat Step 2 & Step 3 for Controller/Storage configurations

Step 5: Prompts to user to allow the Layer2/Layer3 configuration
In this Step, 
1. Script validates the given csv file
2. Merges the Output of Compute (Json file) & Controller/Storage (Json file)
3. At last, Configures Layer2/Layer3 Configuration of Compute Json & Controller/Storage using api


Step 6: Generate the Report under /Report/Current_Date
Name of generated files will be as below
result_dd-mm-yyyy_hh-mm-ss.txt and json_config_dd-mm-yyyy_hh-mm-ss.json
Example: 
Report/18-01-2021/result_18-01-2021_03-51-09.txt
Report/18-01-2021/json_config_18-01-2021_03-51-09.json

